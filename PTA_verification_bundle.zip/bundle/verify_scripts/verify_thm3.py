#!/usr/bin/env python3
"""Exact finite-graph checks for corrected Theorem 3; no deck action on a quotient is asserted."""

from collections import Counter, deque


def quotient_truncation(p, core_edges, h):
    assert p >= 2 and h >= 1
    core = sorted({v for edge in core_edges for v in edge})
    degree = Counter()
    for u, v in core_edges:
        degree[u] += 1
        degree[v] += 1
    assert all(degree[v] <= p + 1 for v in core)
    vertices = list(core)
    edges = [(u, v, f"core{i}") for i, (u, v) in enumerate(core_edges)]
    hair_count = sum(p + 1 - degree[v] for v in core)
    next_id = 0
    for v in core:
        for _ in range(p + 1 - degree[v]):
            next_id += 1
            root = f"hair{next_id}"
            vertices.append(root)
            edges.append((v, root, f"edge{len(edges)}"))
            frontier = [root]
            for _ in range(1, h):
                children = []
                for parent in frontier:
                    for _ in range(p):
                        next_id += 1
                        child = f"hair{next_id}"
                        vertices.append(child)
                        edges.append((parent, child, f"edge{len(edges)}"))
                        children.append(child)
                frontier = children
    return core, hair_count, vertices, edges


def check(label, condition, detail):
    print(f"[{'PASS' if condition else 'FAIL'}] {label}: {detail}")
    return condition


def main():
    p = 3
    core_edges = [('v0', 'm1'), ('v0', 'm1'),
                  ('v0', 'm2'), ('v0', 'm2')]
    ok = True
    print("Corrected Theorem 3: p=3, two-cycle bouquet core")
    for h in range(1, 6):
        core, H, vertices, edges = quotient_truncation(p, core_edges, h)
        n, e = len(vertices), len(edges)
        core_e = len(core_edges)
        expected_hair = H * (p**h - 1) // (p - 1)
        deg = Counter()
        for u, v, _ in edges:
            deg[u] += 1
            deg[v] += 1
        leaf_count = H * p**(h - 1)
        counts = (n == len(core) + expected_hair and e == core_e + expected_hair
                  and 2 * e == 2 * (core_e + expected_hair))
        regular = (all(deg[v] == p + 1 for v in vertices if deg[v] != 1)
                   and sum(deg[v] == 1 for v in vertices) == leaf_count)
        ok &= check(f"T3.1 h={h} counts and degrees", counts and regular,
                    f"V={n}, E={e}, directed arcs={2*e}, interior={n-leaf_count}, leaves={leaf_count}")

    core, H, vertices, edges = quotient_truncation(p, core_edges, 3)
    genus = len(core_edges) - len(core) + 1
    ok &= check("T3.2 hair count from core genus",
                H == (p - 1) * len(core) - 2 * (genus - 1) == 4,
                f"g={genus}, H={H}")
    ratios = []
    for h in range(1, 5):
        _, _, a, _ = quotient_truncation(p, core_edges, h)
        _, _, b, _ = quotient_truncation(p, core_edges, h + 1)
        ratios.append((len(b) - len(core)) > (len(a) - len(core)))
    ok &= check("T3.3 exact exponential size formula", all(ratios),
                "V_h=3+2(3^h-1); hence V_h=Theta(3^h), not polynomial in h")

    # For any group action, q(g.x)=q(x) by the definition of orbit quotient.
    # A small, explicit free Z-action illustrates both this fact and why a
    # finite window of the covering tree is not stable under a translation.
    quotient = lambda n: n % 2  # Z acts on Z by even translations; quotient is a 2-cycle
    samples = range(-12, 13)
    ok &= check("T3.4 deck action descends as identity on orbit quotient",
                all(quotient(n + 2) == quotient(n) for n in samples),
                "q(n+2)=q(n) for every tested n; general claim follows from orbit definition")
    window = set(range(-3, 4))
    ok &= check("T3.5 finite covering-tree window not deck invariant",
                {n + 2 for n in window} != window,
                "translation by 2 sends the finite window [-3,3] outside itself")

    # Deliberately retain a *different* valid permutation: exchange two
    # parallel core edges while fixing their endpoints. This is a quotient
    # graph automorphism, not a nontrivial deck transformation.
    swap = {label: label for _, _, label in edges}
    swap['core0'], swap['core1'] = 'core1', 'core0'
    ok &= check("T3.6 core-edge swap is only a graph symmetry",
                set(swap) == set(swap.values()) and swap['core0'] == 'core1',
                "permutation of edge labels; no deck-generator identification")
    ok &= check("T3.7 explicit graph construction cost",
                len(vertices) == 55 and len(edges) == 56,
                "one vertex and one edge appended per hair vertex: O(V_h+E_h) time and space")
    print("\nALL PASS" if ok else "\nSOME FAILED")
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
