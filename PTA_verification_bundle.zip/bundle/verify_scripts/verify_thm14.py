#!/usr/bin/env python3
"""Finite checks for Theorem 14; these do not prove asymptotic gap or complexity bounds."""
from fractions import Fraction
from math import isclose
import numpy as np


def graph(h, p=3):
    core = ((0, 1), (0, 1), (0, 2), (0, 2))
    edges = list(core)
    n = 3

    def branch(root, depth):
        nonlocal n
        if depth == 0:
            return
        for _ in range(p):
            child = n
            n += 1
            edges.append((root, child))
            branch(child, depth - 1)

    for root in (1, 2):
        for _ in range(2):
            child = n
            n += 1
            edges.append((root, child))
            branch(child, h - 1)
    return n, edges


def adjacency(n, edges):
    a = np.zeros((n, n), dtype=np.int64)
    for u, v in edges:
        a[u, v] += 1
        a[v, u] += 1
    return a


def check(label, condition, detail):
    print(f"[{'PASS' if condition else 'FAIL'}] {label}: {detail}")
    return condition


def main():
    good = True
    sizes = []
    gaps = []
    for h in range(1, 6):
        n, edges = graph(h)
        sizes.append(n)
        assert n == 1 + 2 * 3**h  # 3 core vertices and 4 rooted ternary hairs
        a = adjacency(n, edges) / 4.0
        spectrum = np.linalg.eigvalsh(a)
        gaps.append(float(spectrum[-1] - spectrum[-2]))
        good &= check(f"T14 finite graph h={h}",
                      np.allclose(a, a.T) and np.linalg.norm(a, ord=np.inf) <= 1
                      and -1 - 1e-12 <= spectrum[0] <= spectrum[-1] <= 1 + 1e-12,
                      f"N={n}, top gap Δ_h≈{gaps[-1]:.6f} (floating point)")
    good &= check("T14 sampled gaps", all(gaps[i] > gaps[i+1] for i in range(4)),
                  "strictly decreasing for h=1,…,5 ONLY; no asymptotic conclusion")

    n, edges = graph(2)
    t = adjacency(n, edges)
    # Exact rational moments of a basis-state density matrix rho=|v><v|.
    v = 1
    linear = Fraction(int(t[v, v]), 4)
    square = Fraction(int((t @ t)[v, v]), 16)
    good &= check("T14 polynomial functional exact benchmark",
                  linear == 0 and square == Fraction(3, 8),
                  f"Tr(ρ A)={linear}, Tr(ρ A²)={square} for h=2")
    # The unitary dilation gives an explicit block encoding for *this finite matrix*.
    a = t / 4.0
    eig, vec = np.linalg.eigh(np.eye(n) - a @ a)
    root = (vec * np.sqrt(np.maximum(eig, 0))) @ vec.T
    u = np.block([[a, root], [root, -a]])
    good &= check("T14 concrete finite block encoding",
                  np.min(eig) >= -1e-12 and np.allclose(u.T @ u, np.eye(2*n), atol=1e-12)
                  and np.allclose(u[:n, :n], a, atol=1e-12),
                  "U is unitary and corner=A to 1e-12; dense matrix, NOT poly(h) gates")
    # In this concrete case <0,v|U|0,v> equals Tr(rho A).
    good &= check("T14 encoded expectation", isclose(u[v, v], float(linear), abs_tol=1e-12),
                  f"matrix-element expectation={u[v,v]:.6f}; no QSVT/readout simulated")
    constant = Fraction(1, 4)
    good &= check("T14 no universal classical lower bound", constant == Fraction(1, 4),
                  "q(x)=1/4 gives Tr(ρ q(A))=1/4 without reading the graph")
    print("SCOPE: Finite eigenspectra are numerical. No uniform Δ_h claim, classical")
    print("       lower bound, scalable circuit, QSVT, amplitude-estimation runtime,")
    print("       Diophantine implication, or quantum advantage is established here.")
    print("ALL FINITE CHECKS PASS" if good else "SOME FINITE CHECKS FAILED")
    return 0 if good else 1


if __name__ == '__main__':
    raise SystemExit(main())
