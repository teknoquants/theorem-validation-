#!/usr/bin/env python3
"""Exact finite computations for corrected Theorem 12.

The theorem concerns reduction of GL_2(Z_p) and finite observables; finite
examples illustrate its universal statement, which is proved in the document.
"""
from itertools import product


p, n = 3, 3
m = p**n
large = p**(n+1)
I2 = (1, 0, 0, 1)


def check(label, condition, detail):
    print(f"[{'PASS' if condition else 'FAIL'}] {label}: {detail}")
    return bool(condition)


def product_mod(A, B, modulus):
    a, b, c, d = A
    e, f, g, h = B
    return ((a*e+b*g) % modulus, (a*f+b*h) % modulus,
            (c*e+d*g) % modulus, (c*f+d*h) % modulus)


def det(A, modulus):
    a, b, c, d = A
    return (a*d-b*c) % modulus


def reduction(A, modulus):
    return tuple(x % modulus for x in A)


def inv_mod(A, modulus):
    a, b, c, d = A
    invdet = pow(det(A, modulus), -1, modulus)
    return tuple((invdet*x) % modulus for x in (d, -b, -c, a))


def observable(A, modulus):
    a, _, _, d = A
    return ((a+d) % modulus, det(A, modulus))


def main():
    good = True
    coeffs = list(product(range(p), repeat=4))
    K = [tuple((I2[i]+m*X[i]) % large for i in range(4)) for X in coeffs]
    Kset = set(K)
    matrices = [(1, 0, 0, 1), (2, 1, 3, 2), (4, 2, 1, 1), (1, 1, 0, 1)]
    # Filter with the genuine unit condition rather than assuming sample inputs.
    matrices = [g for g in matrices if det(g, p) != 0]
    stable = all(reduction(product_mod(h, g, large), m) == reduction(g, m)
                 and observable(product_mod(h, g, large), m) == observable(g, m)
                 for h in K for g in matrices)
    good &= check('T12.1 factorization through reduction mod p^n', stable,
                  f'{len(K)*len(matrices)} exact kernel-action comparisons')

    kernel_ok = (len(K) == p**4 and len(Kset) == p**4
                 and all(det(h, p) != 0 and reduction(h, m) == I2 for h in K)
                 and all(product_mod(h, inv_mod(h, large), large) == I2 for h in K)
                 and all(product_mod(h, k, large) in Kset for h in K for k in K))
    gl2_modp = (p*p-1)*(p*p-p)
    gl2_modpn = gl2_modp * p**(4*(n-1))
    small_gl2 = sum(det(A, p) != 0 for A in product(range(p*p), repeat=4))
    good &= check('T12.2 K_n size versus index',
                  kernel_ok and small_gl2 == gl2_modp*p**4 and gl2_modpn != p**4,
                  f'|K_n/K_(n+1)|={len(K)}; '
                  f'|GL2(Z/9)|={small_gl2}; '
                  f'[GL2(Z/p^(n+1)):K_n/K_(n+1)]={gl2_modpn}')

    g = I2
    gp = (1+p**(n-1), 0, 0, 1)
    good &= check('T12.3 exact threshold counterexample',
                  reduction(gp, p**(n-1)) == reduction(g, p**(n-1))
                  and reduction(gp, m) != reduction(g, m)
                  and det(gp, p) != 0 and observable(gp, m) != observable(g, m),
                  f'trace/det: {observable(g,m)} -> {observable(gp,m)} '
                  f'under a p^(n-1)={p**(n-1)} perturbation')

    h = (1, 1, 0, 1)
    good &= check('T12.4 single observable has a larger stabilizer',
                  reduction(h, m) != I2 and observable(h, m) == observable(g, m),
                  f'h not in K_n yet trace/det(h)={observable(h,m)}=trace/det(I)')

    family = lambda t: (1+t, 0, 0, 1)  # rho_t(generator) for Gamma=profinite Z, t in 3 Z_3.
    t_values = (0, 3, 9, 27, 81)
    continuous_example = (all(det(family(t), p) != 0 for t in t_values)
                          and observable(family(9), m) != observable(family(0), m)
                          and all(observable(family(t), m) == observable(family(0), m)
                                  for t in (27, 81)))
    good &= check('T12.5 continuous 3-adic representation family', continuous_example,
                  'rho_t(1)=diag(1+t,1); t=9 changes level 27; '
                  't divisible by 27 fixes level 27')

    print('SCOPE: no Diophantine metric, Chow ring, log-theta-lattice,')
    print('       hardware property, or arbitrary Galois deformation is computed.')
    print('ALL EXACT CHECKS PASS' if good else 'SOME CHECKS FAILED')
    return good


if __name__ == '__main__':
    raise SystemExit(0 if main() else 1)
