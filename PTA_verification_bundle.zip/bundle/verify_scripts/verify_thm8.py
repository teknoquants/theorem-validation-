#!/usr/bin/env python3
"""Exact finite-field and permutation-matrix checks for corrected Theorem 8.

All finite examples are exhaustive; the proof for arbitrary p and k is in the
theorem document. Also checks a nongenerating power of Frobenius on F_16.
"""
from itertools import product
import numpy as np


def remainder(poly, divisor, p):
    work = list(poly)
    while len(work) >= len(divisor):
        lead = work[-1] * pow(divisor[-1], -1, p) % p
        offset = len(work)-len(divisor)
        for i, coeff in enumerate(divisor):
            work[offset+i] = (work[offset+i]-lead*coeff) % p
        while work and work[-1] == 0:
            work.pop()
    return work


def irreducible(p, k):
    if k == 1:
        return (0, 1)
    for low in product(range(p), repeat=k):
        if low[0] == 0:
            continue
        poly = tuple(low)+(1,)
        if all(remainder(poly, tuple(c)+(1,), p)
               for degree in range(1, k//2+1)
               for c in product(range(p), repeat=degree)):
            return poly
    raise RuntimeError('No irreducible polynomial found')


def field(p, k):
    poly = irreducible(p, k)
    elems = list(product(range(p), repeat=k))
    zero = (0,)*k
    one = (1,)+(0,)*(k-1)

    def add(u, v):
        return tuple((a+b)%p for a,b in zip(u,v))

    def mul(u, v):
        out = [0]*(2*k-1)
        for i,a in enumerate(u):
            for j,b in enumerate(v):
                out[i+j] = (out[i+j]+a*b)%p
        for i in range(len(out)-1,k-1,-1):
            coeff=out[i]
            for j in range(k):
                out[i-k+j]=(out[i-k+j]-coeff*poly[j])%p
        return tuple(out[:k])

    def power(u,n):
        result=one
        while n:
            if n&1:
                result=mul(result,u)
            u=mul(u,u)
            n//=2
        return result

    return elems,zero,one,add,mul,power,poly


def perm_matrix(elems, fn):
    index={e:i for i,e in enumerate(elems)}
    matrix=np.zeros((len(elems),len(elems)), dtype=np.int64)
    for i,e in enumerate(elems):
        matrix[index[fn(e)],i]=1
    return matrix


def check(label,passed,detail):
    print(f"[{'PASS' if passed else 'FAIL'}] {label}: {detail}")
    return bool(passed)


def run(p,k):
    elems,zero,one,add,mul,power,poly=field(p,k)
    frob=lambda x:power(x,p)
    Phi=perm_matrix(elems,frob)
    eye=np.eye(len(elems),dtype=np.int64)
    ok=True
    ring_ok=(all(frob(add(x,y))==add(frob(x),frob(y))
                 and frob(mul(x,y))==mul(frob(x),frob(y))
                 for x in elems for y in elems)
             and frob(one)==one and np.array_equal(Phi.T@Phi,eye))
    ok &= check(f'T8.1 F_{p}^{k} Frobenius automorphism',ring_ok,
                f'polynomial={poly}, {len(elems)**2} add/mul pairs')
    fixed={x for x in elems if frob(x)==x}
    prime={(n,)+(0,)*(k-1) for n in range(p)}
    ok &= check(f'T8.2 fixed field p={p}, k={k}',fixed==prime,
                f'fixed elements={len(fixed)} (expected p={p})')

    gates=[]
    commute=0
    all_gate_ok=True
    for a in elems:
        if a==zero:
            continue
        for b in elems:
            M=perm_matrix(elems,lambda x,a=a,b=b:add(mul(a,x),b))
            bijective=np.array_equal(M.T@M,eye)
            central=np.array_equal(Phi@M,M@Phi)
            criterion=(a in fixed and b in fixed)
            all_gate_ok &= bijective and (central==criterion)
            commute+=central
            gates.append((a,b,M))
    ok &= check(f'T8.3 all affine gates p={p}, k={k}',
                all_gate_ok and len(gates)==(p**k)*(p**k-1) and commute==p*(p-1),
                f'tested={len(gates)}, commute={commute}, expected={p*(p-1)}')

    if p==3 and k==2:
        by_params={(a,b):M for a,b,M in gates}
        law=all(np.array_equal(M@N,by_params[(mul(a,c),add(mul(a,d),b))])
                for a,b,M in gates for c,d,N in gates)
        faithful=len({tuple(M.ravel()) for _,_,M in gates})==len(gates)
        ok &= check('T8.4 faithful affine group representation F_9',law and faithful,
                    f'all {len(gates)**2} compositions and {len(gates)} distinct matrices')

    if p==2 and k==4:
        Phi2=Phi@Phi
        fixed2={x for x in elems if power(x,p*p)==x}
        central2=sum(np.array_equal(Phi2@M,M@Phi2) for _,_,M in gates)
        ok &= check('T8.5 nongenerating Frobenius power F_16',
                    len(fixed2)==4 and central2==4*(4-1) and commute==2,
                    f'Phi centralizer={commute}, Phi^2 centralizer={central2}')
    return ok


if __name__=='__main__':
    success=all(run(p,k) for p,k in [(3,1),(2,2),(3,2),(5,2),(2,4)])
    print('\nALL EXACT CHECKS PASS' if success else '\nSOME CHECKS FAILED')
    raise SystemExit(0 if success else 1)
