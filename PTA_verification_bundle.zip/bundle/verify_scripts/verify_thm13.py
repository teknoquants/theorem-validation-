#!/usr/bin/env python3
"""Finite, exact illustrations and counterexamples for corrected Theorem 13.

No finite enumeration proves finality of A^omega; its general proof is in the
document. The stream ultrametric is a chosen prefix metric, not a p-adic norm.
"""
from fractions import Fraction
from itertools import product
from math import factorial

A = (0, 1, 2)
S = (0, 1, 2, 3)
out = (1, 0, 2, 1)
nxt = (1, 2, 3, 1)


def check(label, condition, detail):
    print(f"[{'PASS' if condition else 'FAIL'}] {label}: {detail}")
    return bool(condition)


def prefix(state, depth):
    symbols = []
    for _ in range(depth):
        symbols.append(out[state])
        state = nxt[state]
    return tuple(symbols)


def main():
    ok = True
    iso = all((head,) + tail == word
              for depth in range(1, 7)
              for word in product(A, repeat=depth)
              for head, tail in ((word[0], word[1:]),))
    inverse = all(((a,) + word)[0] == a and ((a,) + word)[1:] == word
                  for a in A for word in product(A, repeat=4))
    ok &= check('T13.1 finite-prefix head/tail and cons', iso and inverse,
                'all words of lengths 1,…,6 (not the infinite-stream bijection)')

    homo = all(prefix(s, depth)[0] == out[s]
               and prefix(s, depth)[1:] == prefix(nxt[s], depth-1)
               for s in S for depth in range(1, 9))
    ok &= check('T13.2 finite-depth anamorphism equations', homo,
                'head and tail commute for every state through depth 8')

    # All possible assignments h:S->A^3. The first-symbol and shift equations
    # filter candidates; exactly one finite-depth homomorphism survives.
    solutions = []
    for symbols in product(A, repeat=len(S)*3):
        h = [symbols[3*i:3*i+3] for i in S]
        if all(h[s][0] == out[s] for s in S) and all(
                h[s][j] == h[nxt[s]][j-1]
                for s in S for j in (1, 2)):
            solutions.append(h)
    unique = len(solutions) == 1 and all(
        solutions[0][s] == prefix(s, 3) for s in S)
    ok &= check('T13.3 exhaustive depth-3 uniqueness', unique,
                f'{len(A)**(len(S)*3)} candidate maps; {len(solutions)} solution')

    # A^0={*}; the 1,2,3 stages are A,A^2,A^3. A coherent family at
    # these stages is uniquely specified by its length-3 prefix.
    coherent = [(w1, w2, w3)
                for w1 in product(A, repeat=1)
                for w2 in product(A, repeat=2)
                for w3 in product(A, repeat=3)
                if w3[:2] == w2 and w2[:1] == w1]
    ok &= check('T13.4 finite final-chain compatibility',
                len(coherent) == len(A)**3
                and all((w1, w2, w3) == (w3[:1], w3[:2], w3)
                        for w1, w2, w3 in coherent),
                f'{len(coherent)} compatible families through stage 3')

    p = 3
    # Target stream 111...; standard approximant first n ones then 000...
    # first mismatch occurs exactly at index n.
    distances = [Fraction(1, p**n) for n in range(1, 11)]
    not_universal_factorial = any(distances[n-1] > Fraction(1, factorial(n))
                                  for n in range(1, 11))
    eventually_exact = (0, 1, 0, 0, 0)  # padded prefixes equal this stream after depth 2.
    ok &= check('T13.5 geometric bound is not a factorial prohibition',
                not_universal_factorial and all(x == 0 for x in eventually_exact[2:]),
                'for 111... vs its zero-padded n-prefix: d=3^-n; '
                'a stream eventually zero becomes exact after finite depth')

    period = tuple(prefix(1, 12))
    periodic = period == (0, 2, 1)*4 and len(set(period)) > 1
    ok &= check('T13.6 final stream need not stabilize', periodic,
                f'four periods={period}; no eventual constant output')

    print('SCOPE: the script cannot enumerate A^omega, prove the universal')
    print('       property for all Set-coalgebras, or establish PTA/IUTT outputs.')
    print('ALL EXACT FINITE CHECKS PASS' if ok else 'SOME FINITE CHECKS FAILED')
    return ok


if __name__ == '__main__':
    raise SystemExit(0 if main() else 1)
