#!/usr/bin/env python3
"""Exact rational-matrix tests for corrected Theorem 10.

The matrices define genuine quiver representations, including nonzero arrows.
Q is a subfield of C, so exact rational identities are valid complex examples.
Finite tests do not prove exactness for every finite-dimensional A-module.
"""
from fractions import Fraction as Q


VERTICES = ('v0', 'm1', 'm2')
ARROWS = (('v0', 'm1'), ('v0', 'm1'), ('m1', 'v0'), ('m1', 'v0'),
          ('v0', 'm2'), ('v0', 'm2'), ('m2', 'v0'), ('m2', 'v0'))


def matrix_product(A, B):
    return [[sum((a*b for a, b in zip(row, col)), Q(0)) for col in zip(*B)]
            for row in A]


def rank(A):
    if not A or not A[0]:
        return 0
    M = [list(map(Q, row)) for row in A]
    r = 0
    for col in range(len(M[0])):
        pivot = next((i for i in range(r, len(M)) if M[i][col]), None)
        if pivot is None:
            continue
        M[r], M[pivot] = M[pivot], M[r]
        factor = M[r][col]
        M[r] = [x/factor for x in M[r]]
        for i in range(len(M)):
            if i != r:
                factor = M[i][col]
                M[i] = [x-factor*y for x, y in zip(M[i], M[r])]
        r += 1
    return r


def block(A, B):
    top = [row + [Q(0)]*len(B[0]) for row in A]
    bottom = [[Q(0)]*len(A[0]) + row for row in B]
    return top + bottom


def zero(A):
    return all(all(x == 0 for x in row) for row in A)


def assert_check(name, value, detail=''):
    print(f"[{'PASS' if value else 'FAIL'}] {name}: {detail}")
    return bool(value)


def sequence(t):
    # At every vertex: 0 -> Q --i--> Q^2 --pi--> Q -> 0.
    # Each oriented arrow: M=1, N=2, E=[[1,t],[0,2]].
    i = [[Q(1)], [Q(0)]]
    pi = [[Q(0), Q(1)]]
    E_arrow = [[Q(1), Q(t)], [Q(0), Q(2)]]
    return i, pi, [[Q(1)]], E_arrow, [[Q(2)]]


def main():
    ok = True
    i, pi, Ma, Ea, Na = sequence(1)
    j, sigma, Mb, Eb, Nb = sequence(3)
    arrow_ok = all(matrix_product(Ea, i) == matrix_product(i, Ma)
                   and matrix_product(pi, Ea) == matrix_product(Na, pi)
                   and matrix_product(Eb, j) == matrix_product(j, Mb)
                   and matrix_product(sigma, Eb) == matrix_product(Nb, sigma)
                   for _ in ARROWS)
    vertex_ok = (rank(i) == rank(j) == rank(pi) == rank(sigma) == 1
                 and zero(matrix_product(pi, i)) and zero(matrix_product(sigma, j)))
    ok &= assert_check('T10.1 two short exact A-module sequences',
                       vertex_ok and arrow_ok,
                       f'{len(VERTICES)} vertex spaces; {len(ARROWS)} nonzero arrow maps')

    I = block(i, j)
    Pi = block(pi, sigma)
    EM = block(Ea, Eb)
    MM = block(Ma, Mb)
    NN = block(Na, Nb)
    sum_exact = (rank(I) == 2 and rank(Pi) == 2 and zero(matrix_product(Pi, I))
                 and 4-rank(Pi) == rank(I))
    sum_arrow = (matrix_product(EM, I) == matrix_product(I, MM)
                 and matrix_product(Pi, EM) == matrix_product(NN, Pi))
    ok &= assert_check('T10.2 direct sum bifunctor preserves short exact pairs',
                       sum_exact and sum_arrow,
                       'vertex ranks (2,2), im=ker, and arrow intertwiners checked exactly')

    # F_P(f) = f ⊕ id_P. Applying this to BOTH maps of a SES fails to yield
    # a complex: (pi ⊕ id_P)(i ⊕ id_P) = (pi i) ⊕ id_P.
    ident_P = [[Q(1)]]
    FP_i = block(i, ident_P)
    FP_pi = block(pi, ident_P)
    composition = matrix_product(FP_pi, FP_i)
    ok &= assert_check('T10.3 fixed-P addition is NOT an exact endofunctor',
                       not zero(composition) and composition == block([[Q(0)]], ident_P),
                       f'F_P(pi) F_P(i)={composition} (nonzero)')
    ok &= assert_check('T10.4 fixed-P addition is not additive on Hom-sets',
                       block([[Q(0)]], ident_P) != [[Q(0), Q(0)], [Q(0), Q(0)]],
                       'F_P(0)=0 ⊕ id_P is not a zero morphism when P ≠ 0')

    good = Q(3, 5)
    variance = good*(1-good)
    ok &= assert_check('T10.5 categorical exactness says nothing about readout noise',
                       variance == Q(6, 25) and variance > 0,
                       f'Bernoulli probability={good}, variance={variance}')
    print('SCOPE: these finite examples do not establish physical noise rates,')
    print('       theta-link structures, or general exactness by enumeration.')
    print('ALL EXACT CHECKS PASS' if ok else 'SOME CHECKS FAILED')
    return ok


if __name__ == '__main__':
    raise SystemExit(0 if main() else 1)
