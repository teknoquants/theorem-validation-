#!/usr/bin/env python3
"""Exact rational checks for corrected Theorem 7 (16 arcs, flip U).

Here E=(1-t)id+t*Delta with t=1/2 and Delta complete arc dephasing.
Delta is a diagonal random-unitary channel (uniform average of sign-flip
diagonal unitaries), so this is within Theorem 6's hypothesis. The test
distinguishes decaying coherences from non-convergent periodic populations.
"""
from fractions import Fraction as F

N = 16
MU = F(1, 2)
PERM = tuple(i ^ 1 for i in range(N))  # reverse the two arcs of each edge
S = sum(i*i for i in range(1, N+1))
RHO0 = tuple(tuple(F((i+1)*(j+1), S) for j in range(N)) for i in range(N))


def phi(rho):
    return tuple(tuple(rho[PERM[i]][PERM[j]] * (1 if i == j else MU)
                       for j in range(N)) for i in range(N))


def off_square(rho):
    return sum(rho[i][j]**2 for i in range(N) for j in range(N) if i != j)


def diagonal(rho):
    return tuple(rho[i][i] for i in range(N))


def check(label, passed, detail):
    print(f"[{'PASS' if passed else 'FAIL'}] {label}: {detail}")
    return bool(passed)


def main():
    ok = True
    ok &= check('T7.1 CPTP ingredients',
                set(PERM) == set(range(N)) and all(PERM[PERM[i]] == i for i in range(N))
                and 0 <= MU < 1,
                'Ad_U unitary; E=(1/2)id+(1/2)Delta is CPTP')
    rho = RHO0
    norm0 = off_square(rho)
    samples = [rho]
    for _ in range(8):
        rho = phi(rho)
        samples.append(rho)
    ok &= check('T7.2 exact coherence decay',
                all(off_square(r) == MU**(2*n)*norm0
                    for n, r in enumerate(samples)),
                '||off(rho_n)||_2^2=(1/2)^(2n)||off(rho_0)||_2^2, n=0,...,8')
    p0 = diagonal(RHO0)
    p1 = tuple(p0[PERM[i]] for i in range(N))
    periodic = p0 != p1 and all(diagonal(r) == (p0 if n % 2 == 0 else p1)
                                    for n, r in enumerate(samples))
    ok &= check('T7.3 population period and failure of state convergence',
                periodic, 'p_(2n)=p_0 != p_1=p_(2n+1); rho_n has no single limit')
    c = sum(1 for i in range(N) if i < PERM[i])
    avg = tuple((p0[i]+p1[i])/2 for i in range(N))
    fixed = all(avg[i] == avg[PERM[i]] for i in range(N))
    ok &= check('T7.4 fixed states and Cesaro limit', c == 8 and fixed,
                '8 flip cycles; diagonal fixed-state simplex has affine dimension 7')
    even_average = tuple(sum(diagonal(r)[i] for r in samples[:8])/8
                         for i in range(N))
    ok &= check('T7.5 exact eight-step diagonal Cesaro average',
                even_average == avg,
                'even-length diagonal time average equals the fixed cycle average')
    ok &= check('T7.6 trace preserved exactly',
                all(sum(diagonal(r)) == 1 for r in samples),
                'Tr(rho_n)=1 for n=0,...,8')
    print('GENERAL PROOF: off decay plus periodicity yields convergence of each')
    print('residue-class subsequence and of Cesaro means; not of every orbit.')
    print('NOT TESTED: a physical walk, period valuations, or Szpiro/ABC assertions.')
    print('\nALL EXACT CHECKS PASS' if ok else '\nSOME CHECKS FAILED')
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
