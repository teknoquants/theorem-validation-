#!/usr/bin/env python3
"""Exact rational verification of corrected Theorem 6 on the 16-arc example.

The model is E(rho)=sum_j q_j D_j rho D_j^dagger. The script checks
identities in Q(i) by keeping real/imaginary parts as Fractions. It makes
no physical transducer, IUTT, or period-lattice inference.
"""
from fractions import Fraction as F

P = 3
CORE = [('v0', 'm1'), ('v0', 'm1'), ('v0', 'm2'), ('v0', 'm2')]
HAIR = [('m1', f'h{k}') for k in range(2)] + [('m2', f'h{k}') for k in range(2, 4)]
EDGES = CORE + HAIR
N = 2 * len(EDGES)
CORE_ARCS = frozenset(range(2 * len(CORE)))
HAIR_ARCS = frozenset(range(2 * len(CORE), N))
Q = (F(1, 2), F(1, 3), F(1, 6))
ROOTS = ((1, 0), (0, 1), (-1, 0), (0, -1))


def multiply(x, y):
    return (x[0]*y[0]-x[1]*y[1], x[0]*y[1]+x[1]*y[0])


def conjugate(x):
    return (x[0], -x[1])


def phase(j, e):
    return ROOTS[(0, 2*e, e)[j] % 4]


def gamma(e, f):
    re, im = F(0), F(0)
    for j, q in enumerate(Q):
        term = multiply(phase(j, e), conjugate(phase(j, f)))
        re += q * term[0]
        im += q * term[1]
    return (re, im)


def check(label, ok, detail):
    print(f"[{'PASS' if ok else 'FAIL'}] {label}: {detail}")
    return bool(ok)


def main():
    ok = True
    print(f'X_1: {N} directed arcs ({len(CORE_ARCS)} core, {len(HAIR_ARCS)} hair)')
    ok &= check('T6.1 exact CPTP/unital normalization',
                N == 16 and sum(Q) == 1
                and all(multiply(phase(j,e),conjugate(phase(j,e))) == (1,0)
                        for j in range(len(Q)) for e in range(N)),
                'sum_j K_j^dagger K_j=sum_j K_j K_j^dagger=I, K_j=sqrt(q_j)D_j')
    ok &= check('T6.2 exact diagonal preservation',
                all(gamma(e,e) == (1,0) for e in range(N)),
                'E(|e><e|)=|e><e| for all 16 arcs')
    ok &= check('T6.3 exact four-block invariance',
                (CORE_ARCS | HAIR_ARCS) == frozenset(range(N))
                and not (CORE_ARCS & HAIR_ARCS)
                and all(e in CORE_ARCS or e in HAIR_ARCS for e in range(N)),
                'E(|e><f|)=gamma_ef |e><f|; both diagonal and cross blocks invariant')
    bounded = all(a*a+b*b <= 1 for e in range(N) for f in range(N)
                  for a,b in [gamma(e,f)])
    hermitian = all(gamma(f,e) == conjugate(gamma(e,f))
                    for e in range(N) for f in range(N))
    ok &= check('T6.4 complex coherence multipliers bounded', bounded and hermitian,
                f'gamma_0,1={gamma(0,1)}, |gamma_ef|<=1 for all pairs')
    cross = gamma(0, 8)
    ok &= check('T6.5 counterexample to loss of core-hair coherence',
                0 in CORE_ARCS and 8 in HAIR_ARCS and cross == (1,0),
                'gamma_0,8=1, so existing cross-block coherence can survive')
    print('NOT TESTED: a physical U and sigma_ph, period valuations v_p(q_ij),')
    print('            any hardware or IUTT identification.')
    print('\nALL EXACT CHECKS PASS' if ok else '\nSOME CHECKS FAILED')
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
