#!/usr/bin/env python3
"""Exact checks for corrected Theorem 11.

The complex projection uses integer Gaussian arithmetic; density matrices and
channels use rational arithmetic. The p-adic examples check primitive solutions
at increasing powers of odd p and invoke the nonsingular Hensel condition.
Finite examples do not prove the general Hilbert-space or CPTP results.
"""
from fractions import Fraction as F


def check(label, condition, detail):
    print(f"[{'PASS' if condition else 'FAIL'}] {label}: {detail}")
    return bool(condition)


def add(a, b):
    return (a[0]+b[0], a[1]+b[1])


def mul(a, b):
    return (a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0])


def conj(a):
    return (a[0], -a[1])


def mm(A, B):
    return [[sum_g((mul(A[i][k], B[k][j]) for k in range(len(B))))
             for j in range(len(B[0]))] for i in range(len(A))]


def sum_g(items):
    result = (0, 0)
    for item in items:
        result = add(result, item)
    return result


def adj(A):
    return [[conj(A[i][j]) for i in range(len(A))] for j in range(len(A[0]))]


def identity(n, scale=1):
    return [[(scale if i == j else 0, 0) for j in range(n)] for i in range(n)]


def minus(A, B):
    return [[(a[0]-b[0], a[1]-b[1]) for a, b in zip(row_a, row_b)]
            for row_a, row_b in zip(A, B)]


def lift_vector(p, digits):
    # Search a^2+b^2+1=0 modulo odd p with b !=0; b is Hensel-lifted.
    base = next(((a, b) for a in range(p) for b in range(1, p)
                 if (a*a+b*b+1) % p == 0), None)
    assert base is not None
    a, b = base
    modulus = p
    witnesses = []
    for _ in range(digits):
        witnesses.append((a, b, 1, 0, 0))
        assert (a*a+b*b+1) % modulus == 0
        assert b % p != 0 and 1 % p != 0
        b = next(b+t*modulus for t in range(p)
                 if (a*a+(b+t*modulus)**2+1) % (modulus*p) == 0)
        modulus *= p
    return witnesses


def main():
    ok = True
    u = [[(1, 0)], [(0, 1)], [(1, 1)], [(0, 0)]]
    Q = mm(u, adj(u))
    n = mm(adj(u), u)[0][0][0]
    R = minus(identity(4, n), Q)
    v = [[(2, 1)], [(1, -1)], [(0, 3)], [(4, 0)]]
    proj_ok = (n == 4 and Q == adj(Q)
               and mm(Q, Q) == [[(n*x[0], n*x[1]) for x in row] for row in Q]
               and mm(Q, R) == [[(0, 0)]*4 for _ in range(4)]
               and mm(R, Q) == [[(0, 0)]*4 for _ in range(4)]
               and mm(adj(mm(Q, v)), mm(R, v)) == [[(0, 0)]]
               and mm(Q, v) != [[(0, 0)]]*4
               and minus(mm(identity(4, n), v), mm(Q, v)) == mm(R, v))
    ok &= check('T11.1 complex orthogonal projection', proj_ok,
                'Q=uu†, Q²=4Q, QR=0, v=(Qv+Rv)/4 exactly')

    rho = [[F(1, 2), F(1, 4)], [F(1, 4), F(1, 2)]]
    U = [[F(0), F(-1)], [F(1), F(0)]]
    Z = [[F(1), F(0)], [F(0), F(-1)]]
    def real_mm(A, B):
        return [[sum((A[i][k]*B[k][j] for k in range(len(B))), F(0))
                 for j in range(len(B[0]))] for i in range(len(A))]
    def transpose(A):
        return [list(row) for row in zip(*A)]
    def trace(A):
        return sum((A[i][i] for i in range(len(A))), F(0))
    unit = real_mm(real_mm(U, rho), transpose(U))
    phase = real_mm(real_mm(Z, rho), transpose(Z))
    channel = [[rho[i][j]/3+2*phase[i][j]/3 for j in range(2)] for i in range(2)]
    ok &= check('T11.2 unitary and random-unitary CPTP trace conservation',
                real_mm(U, transpose(U)) == [[F(1), F(0)], [F(0), F(1)]]
                and trace(rho) == trace(unit) == trace(channel) == 1,
                f'Tr ρ={trace(rho)}, Tr UρU†={trace(unit)}, Tr E(ρ)={trace(channel)}')

    for p in (3, 5, 7, 11):
        witnesses = lift_vector(p, 5)
        valid = all(sum(t*t for t in w) % p**(i+1) == 0
                    and any(t % p for t in w)
                    for i, w in enumerate(witnesses))
        ok &= check(f'T11.3 p={p} selected p-adic quadratic form', valid,
                    f'primitive 5-square witnesses mod p,…,p^5; last={witnesses[-1]}')

    p = 3
    w = lift_vector(p, 5)[-1]
    ok &= check('T11.4 selected orthogonal complement fails to split',
                sum(t*t for t in w) % p**5 == 0 and w[2] == 1,
                'nonsingular Hensel lift yields nonzero x with x·x=0 in Q_3^5; '
                'its line meets its orthogonal complement')
    print('SCOPE: no unconditional nonexistence claim for p-adic orthomodular')
    print('       spaces; no hardware implementation or arbitrary gate claim is tested.')
    print('ALL EXACT CHECKS PASS' if ok else 'SOME CHECKS FAILED')
    return ok


if __name__ == '__main__':
    raise SystemExit(0 if main() else 1)
