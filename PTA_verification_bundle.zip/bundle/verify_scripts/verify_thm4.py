#!/usr/bin/env python3
"""Numerical illustration of corrected Theorem 4; this is NOT a QSVT circuit.

Tests the finite-graph scaling, the necessity of shifting a nonzero threshold,
and the spectral-weight ambiguity bounds. Polynomial existence, boundedness
over the whole interval, block-encoding, and amplitude estimation are theorem
hypotheses/results, not certified by finite sampling here.
"""

import numpy as np


def check(label, condition, detail=""):
    print(f"[{'PASS' if condition else 'FAIL'}] {label}: {detail}")
    return bool(condition)


def graph():
    p = 3
    core = [('v0', 'm1'), ('v0', 'm1'), ('v0', 'm2'), ('v0', 'm2')]
    nodes = ['v0', 'm1', 'm2']
    edges = list(core)
    counter = 0
    for v in ('m1', 'm2'):
        for _ in range(2):
            counter += 1
            root = f'n{counter}'
            nodes.append(root)
            edges.append((v, root))
            for _ in range(p):
                counter += 1
                child = f'n{counter}'
                nodes.append(child)
                edges.append((root, child))
    index = {v: i for i, v in enumerate(nodes)}
    T = np.zeros((len(nodes), len(nodes)), dtype=np.int64)
    for u, v in edges:
        T[index[u], index[v]] += 1
        T[index[v], index[u]] += 1
    return p, T


def main():
    p, T = graph()
    A = T / (p + 1)
    eigenvalues = np.linalg.eigvalsh(A)
    ok = True
    ok &= check('T4.1 finite self-adjoint contraction',
                np.array_equal(T, T.T) and len(T) == 19
                and np.max(np.abs(eigenvalues)) <= 1 + 1e-12,
                f'dim={len(T)}, min={eigenvalues.min():.6f}, max={eigenvalues.max():.6f}')

    lam, delta = 0.2, 0.25
    beta = 1 + abs(lam)
    shifted = (eigenvalues - lam) / beta
    ok &= check('T4.2 shift moves threshold to zero',
                abs((lam - lam) / beta) < 1e-15
                and np.max(np.abs(shifted)) <= 1 + 1e-12,
                f'lambda*={lam}, beta={beta}, gap delta/beta={delta/beta:.6f}')

    # Odd polynomials vanish at 0 and thus cannot represent a displaced
    # step as an odd function of the original eigenvalue x.
    odd_counterexample = (np.sign(-0.1 - lam) != -np.sign(0.1 - lam))
    ok &= check('T4.3 unshifted odd threshold is invalid', odd_counterexample,
                'sign(x-lambda*) is not odd when lambda* != 0')

    # tanh is a bounded, odd SMOOTH surrogate on B, not a finite QSVT polynomial.
    eps = 0.01
    kappa = np.arctanh(1 - eps) / (delta / beta)
    surrogate = np.tanh(kappa * shifted)
    outside = np.abs(eigenvalues - lam) >= delta
    outside_error = (np.max(np.abs(surrogate[outside] - np.sign(shifted[outside])))
                     if np.any(outside) else 0.0)
    ok &= check('T4.4 shifted smooth threshold on sampled spectrum',
                outside_error <= eps + 1e-12,
                f'outside={outside.sum()}, window={(~outside).sum()}, error={outside_error:.3g}')

    weights = np.full(len(T), 1 / len(T))  # maximally mixed state, spectral weights
    Fvals = (1 + surrogate) / 2
    f = float(weights @ Fvals)
    high = float(weights[eigenvalues >= lam + delta].sum())
    window = float(weights[(eigenvalues > lam - delta)
                           & (eigenvalues < lam + delta)].sum())
    lower, upper = high - eps / 2, high + window + eps / 2
    ok &= check('T4.5 spectral-window weight bounds', lower - 1e-12 <= f <= upper + 1e-12,
                f'f={f:.6f}, guaranteed interval=[{lower:.6f}, {upper:.6f}]')

    print('NOT TESTED: polynomial existence/global bound, U_T and U_B, QSVT,')
    print('            controlled state preparation, amplitude estimation, hardware,')
    print('            exact eigenvalues, and Diophantine assertions.')
    print('\nALL NUMERICAL CHECKS PASS' if ok else '\nNUMERICAL CHECK FAILED')
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
