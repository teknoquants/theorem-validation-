#!/usr/bin/env python3
"""Theorem 2 verification (LCU version, matching the user's revised Theorem 2).
Encodes the core-cycle circulant C_c = P + P^{-1} via an EXACT Hadamard-LCU block-encoding,
verified in exact INTEGER arithmetic. Each claim tested by an independent computation.

Explicit construction (ell>=2, m=ceil(log2 ell), n=2^m):
  P = cyclic shift on the logical block C^ell.
  F = P on the logical block, +1 on each padding coordinate.        (signed permutation, unitary)
  B = P^{-1} on the logical block, -1 on each padding coordinate.    (signed permutation, unitary)
  SELECT = |0><0| (x) F + |1><1| (x) B      = [[F,0],[0,B]]
  U_c = (H (x) I) SELECT (H (x) I) = (1/2)[[F+B, F-B],[F-B, F+B]]
  corner (ancilla-zero block) = (F+B)/2 = C_c/2 on the logical block, 0 on padding = C~_c/2.
Tests:
 (A) C_c = P + P^{-1}; for ell=2, C_c = 2P (weighted multicycle, two parallel edges).
 (B) character vectors are eigenvectors AND spectrum matches an independent numpy eigensolve.
 (C) exact NTT diagonalization over F_q (ell | q-1) in modular integer arithmetic.
 (D) N/sqrt(ell) unitary over C; N Ninv = I over F_q (genuine change of basis).
 (E) F,B are exact signed-permutation unitaries: F F^T = I, B B^T = I (exact integers).
 (F) EXACT block-encoding: 2U_c = [[F+B,F-B],[F-B,F+B]] integer matrix with (2U_c)(2U_c)^T = 4 I
     (exact integer identity), and ancilla-zero corner = C_c (+) 0 exactly.
 (G) scope: no QSVT / readout-cost / hardware / whole-graph / S,B claim tested (recorded, not asserted).
"""
import numpy as np
def check(name, ok, detail=""):
    print(f"[{'PASS' if ok else 'FAIL'}] {name}  {detail}")
    return ok
allok=True

def shift(ell):
    P=np.zeros((ell,ell),int)
    for j in range(ell): P[(j+1)%ell,j]=1
    return P
def cyclic_adj(ell):
    P=shift(ell); return P+P.T   # P + P^{-1}; at ell=2 this is 2P

print("== (A) cycle model: C_c = P + P^{-1}; ell=2 is weighted multicycle 2P ==")
for ell in [2,3,4,5,6]:
    P=shift(ell); C=cyclic_adj(ell)
    ok=np.array_equal(C,P+P.T) and np.array_equal(C,C.T)
    detail="C_2 = 2P (two parallel edges)" if ell==2 and np.array_equal(C,2*P) else ""
    allok &= check(f"  ell={ell}: C=P+P^-1 symmetric", ok, detail)

print("== (B) character vectors are eigenvectors; spectrum matches independent eigensolve ==")
for ell in [2,3,4,5,6]:
    C=cyclic_adj(ell).astype(float); w=np.exp(2j*np.pi/ell)
    fv=[np.array([w**(j*k) for j in range(ell)]) for k in range(ell)]
    lam=[2*np.cos(2*np.pi*k/ell) for k in range(ell)]
    eig_ok=all(np.allclose(C@fv[k], lam[k]*fv[k]) for k in range(ell))
    spec_ok=np.allclose(np.sort(np.linalg.eigvalsh(C)), np.sort(np.array(lam)))
    allok &= check(f"  ell={ell}: Cf_k=(2cos)f_k; spectra match numpy", eig_ok and spec_ok,
                   f"spec={np.round(sorted(lam),3).tolist()}")

print("== (C) exact NTT diagonalization over F_q (ell | q-1), modular integers ==")
def find_q(ell):
    q=ell+1
    while True:
        if all(q%d for d in range(2,int(q**0.5)+1)) and (q-1)%ell==0: return q
        q+=1
def rootunity(q,ell):
    for g in range(2,q):
        w=pow(g,(q-1)//ell,q)
        if all(pow(w,d,q)!=1 for d in range(1,ell)): return w
    raise RuntimeError
for ell in [2,3,4,5,6]:
    q=find_q(ell); w=rootunity(q,ell); wi=pow(w,-1,q); li=pow(ell%q,-1,q)
    C=cyclic_adj(ell)%q
    N=np.array([[pow(w,(j*k)%ell,q) for k in range(ell)] for j in range(ell)],dtype=object)
    Ninv=np.array([[(li*pow(wi,(j*k)%ell,q))%q for k in range(ell)] for j in range(ell)],dtype=object)
    D=(N@C%q)@Ninv%q
    pred=[(pow(w,k,q)+pow(wi,k,q))%q for k in range(ell)]
    off0=all(D[i,j]%q==0 for i in range(ell) for j in range(ell) if i!=j)
    dgok=all(D[k,k]%q==pred[k] for k in range(ell))
    allok &= check(f"  ell={ell}, q={q}: exact diag mod q", off0 and dgok, f"diag={[int(D[k,k]) for k in range(ell)]}")

print("== (D) NTT genuine change of basis ==")
for ell in [2,3,4,5,6]:
    w=np.exp(2j*np.pi/ell); N=np.array([[w**(j*k) for k in range(ell)] for j in range(ell)])
    uC=np.allclose(N@N.conj().T, ell*np.eye(ell))
    q=find_q(ell); wq=rootunity(q,ell); wi=pow(wq,-1,q); li=pow(ell%q,-1,q)
    Nq=np.array([[pow(wq,(j*k)%ell,q) for k in range(ell)] for j in range(ell)],dtype=object)
    Niq=np.array([[(li*pow(wi,(j*k)%ell,q))%q for k in range(ell)] for j in range(ell)],dtype=object)
    idq=(Nq@Niq)%q; invq=all(idq[i,j]%q==(1 if i==j else 0) for i in range(ell) for j in range(ell))
    allok &= check(f"  ell={ell}: N/sqrt(ell) unitary over C; N Ninv=I over F_q", uC and invq)

def build_FB(ell):
    m=(ell-1).bit_length(); n=1<<m
    P=shift(ell); F=np.zeros((n,n),int); B=np.zeros((n,n),int)
    F[:ell,:ell]=P; B[:ell,:ell]=P.T
    for j in range(ell,n): F[j,j]=1; B[j,j]=-1
    return F,B,n,m

print("== (E) F,B exact signed-permutation unitaries (integer F F^T=I, B B^T=I) ==")
for ell in [2,3,4,5,6]:
    F,B,n,m=build_FB(ell)
    okF=np.array_equal(F@F.T,np.eye(n,dtype=int)); okB=np.array_equal(B@B.T,np.eye(n,dtype=int))
    allok &= check(f"  ell={ell} (n={n}): F,B signed-permutation unitaries", okF and okB)

print("== (F) EXACT block-encoding: (2U_c)(2U_c)^T=4I integer; corner = C_c (+) 0 ==")
for ell in [2,3,4,5,6]:
    F,B,n,m=build_FB(ell); S=F+B; Dm=F-B
    U2=np.block([[S,Dm],[Dm,S]]).astype(int)          # = 2 U_c, integer
    exact=np.array_equal(U2@U2.T, 4*np.eye(2*n,dtype=int))
    corner=U2[:n,:n]                                   # = F+B = 2 * (ancilla-zero corner)
    Ctil=cyclic_adj(ell)
    logical_ok=np.array_equal(corner[:ell,:ell], Ctil)         # corner/2 = C_c/2 on logical
    pad_ok=np.array_equal(corner[ell:,ell:], np.zeros((n-ell,n-ell),int))
    qubits = (1+m)
    allok &= check(f"  ell={ell}: (2U)(2U)^T=4I; corner=C_c(+)0; qubits=1+ceil(log2 ell)={qubits}",
                   exact and logical_ok and pad_ok, f"n={n}, (2,1,0)-encoding")

print("== (G) scope (recorded, not asserted) ==")
allok &= check("  no QSVT/readout/hardware/whole-graph/S,B claim tested", True,
               "those require separate definitions and theorems")

print("\nALL PASS" if allok else "\nSOME FAILED")
