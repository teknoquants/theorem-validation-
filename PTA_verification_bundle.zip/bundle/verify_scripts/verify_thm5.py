#!/usr/bin/env python3
"""Exact Q_3 checks for corrected Theorem 5 in a CYCLIC Schottky example.

For Gamma=<z -> 9z>, Omega(Q_3)=Q_3^x, use a=1,b=2,z=4,z0=5.
The normalized cross-ratio u_n tends to 1 in both directions n -> +/-infty.
The all-n tail conclusion follows from the algebraic valuation identity,
not from enumerating finitely many words. This is NOT a genus-two check.
"""
from fractions import Fraction as F

P = 3
A, B, Z, Z0 = map(F, (1, 2, 4, 5))


def vp(x):
    if not x:
        return float('inf')
    num, den, val = abs(x.numerator), x.denominator, 0
    while num % P == 0:
        num //= P
        val += 1
    while den % P == 0:
        den //= P
        val -= 1
    return val


def factor(n):
    q = F(9) ** n
    return (Z - q * A) * (Z0 - q * B) / ((Z - q * B) * (Z0 - q * A))


def check(label, ok, detail):
    print(f"[{'PASS' if ok else 'FAIL'}] {label}: {detail}")
    return bool(ok)


def main():
    ok = True
    # For every integer n != 0, write q=9^n. Direct cancellation gives
    # u_n-1=q*(Z-Z0)*(A-B)/((Z-q*B)*(Z0-q*A)).
    # All four constants are 3-adic units. For n>0 both denominators are
    # units; for n<0 both have valuation 2*n. Therefore v_3(u_n-1)=2|n|.
    vals = {n: vp(factor(n) - 1) for n in range(-12, 13) if n}
    ok &= check('T5.1 normalized factors',
                all(val == 2 * abs(n) and vp(factor(n)) == 0
                    for n, val in vals.items()),
                'v_3(u_n-1)=2|n| for -12<=n<=12, n!=0; proved for all n')
    qneg = F(9) ** -6
    raw = (Z - qneg * A) / (Z - qneg * B)
    ok &= check('T5.2 raw one-point factors cannot give this proof',
                vp(raw - 1) == 0 and vp(factor(-6) - 1) == 12,
                'raw factor is not close to 1 as n -> -infinity')
    u0 = factor(0)
    ok &= check('T5.3 exceptional central factor retained',
                vp(u0) == 2 and vp(u0 - 1) == 0,
                f'v_3(u_0)={vp(u0)}; it is never discarded')

    for h in range(1, 9):
        # Retain n=0 and those n!=0 with 2|n|<h. Every other n has
        # v_3(u_n-1)>=h by the all-n formula above. Finite products and
        # their p-adic limit remain in the closed subgroup 1+3^h Z_3.
        retained = [n for n in range(-12, 13)
                    if n == 0 or 2 * abs(n) < h]
        finite_tail = F(1)
        for n in range(-12, 13):
            if n not in retained:
                finite_tail *= factor(n)
        ok &= check(f'T5.4 h={h} finite tail and all-n bound',
                    vp(finite_tail - 1) >= h
                    and all(2 * abs(n) >= h for n in range(-100, 101)
                            if n not in retained),
                    f'retain {len(retained)} factors, v_3(sample tail-1)={vp(finite_tail-1)}>=h')

    print('PROOF INPUT: v_3(u_n-1)=2|n| for every nonzero integer n.')
    print('SCOPE: no genus-two Schottky tail bound, tree-depth identity,')
    print('       period lattice, or DS-NAQHA hardware realization is tested.')
    print('\nALL PASS' if ok else '\nSOME FAILED')
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
