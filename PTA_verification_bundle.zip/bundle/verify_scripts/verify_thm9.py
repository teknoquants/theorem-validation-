#!/usr/bin/env python3
"""Finite exact checks and explicit counterexamples for corrected Theorem 9.

These calculations do NOT implement QSVT, a global block-encoding, or amplitude
estimation. The theorem's circuit bounds are conditional mathematical claims.
"""
from fractions import Fraction
from math import asin, ceil, log2, pi, sin, sqrt


def check(name, condition, detail):
    print(f"[{'PASS' if condition else 'FAIL'}] {name}: {detail}")
    return bool(condition)


def build_graph(p, h):
    edges = [(0, 1), (0, 1), (0, 2), (0, 2)]
    next_vertex = 3
    for core_root in (1, 1, 2, 2):
        parent = core_root
        edges.append((parent, next_vertex))
        frontier = [next_vertex]
        next_vertex += 1
        for _ in range(1, h):
            children = []
            for v in frontier:
                for _ in range(p):
                    edges.append((v, next_vertex))
                    children.append(next_vertex)
                    next_vertex += 1
            frontier = children
    return next_vertex, edges


def exact_moment(p, n, edges, rho):
    # q(t)=t^2/2, A=T_p/(p+1), rho diagonal: (A^2)vv = deg(v)/(p+1)^2.
    degrees = [0] * n
    for u, v in edges:
        degrees[u] += 1
        degrees[v] += 1
    assert len(rho) == n and sum(rho) == 1
    return sum((rho[v] * degrees[v] for v in range(n)), Fraction(0)) / (2 * (p + 1) ** 2), degrees


def run():
    ok = True
    p = 3
    counts = []
    for h in range(1, 7):
        n, edges = build_graph(p, h)
        expected = 3 + 4 * (p**h - 1) // (p - 1)
        local_ok = n == expected and len(edges) == n + 1
        if h <= 3:
            rho = [Fraction(1, n)] * n
            moment, degrees = exact_moment(p, n, edges, rho)
            # Independent trace identity: sum_v deg(v)=2|E|.
            local_ok &= moment == Fraction(len(edges), n * (p + 1) ** 2)
            local_ok &= max(degrees) <= p + 1 and min(degrees) == 1
        counts.append(n)
        local_ok &= ceil(log2(2 * len(edges))) <= ceil((h + 2) * log2(p)) + 2
        ok &= check(f'A/B h={h} graph and arc register', local_ok,
                    f'|V|={n}, |E|={len(edges)}, arc qubits={ceil(log2(2*len(edges)))}')

    ok &= check('C counterexample to universal classical Theta(|V|)',
                all(sum((Fraction(1, 4 * n) for _ in range(n)), Fraction(0)) == Fraction(1, 4)
                    for n in counts),
                'q(t)=1/4 implies Tr(rho q(A))=1/4, without visiting all vertices')

    n, edges = build_graph(p, 2)
    rho = [Fraction(0)] * n
    rho[0] = Fraction(1, 3)
    rho[4] = Fraction(2, 3)
    moment, degrees = exact_moment(p, n, edges, rho)
    direct = (rho[0] * degrees[0] + rho[4] * degrees[4]) / 32
    ok &= check('D exact spectral functional for q(t)=t^2/2', moment == direct,
                f'Phi_q(rho)={moment}, degrees at supported vertices={degrees[0]},{degrees[4]}')

    # The one-marked-item mean is 1/N, not 1/sqrt(N); its state amplitude is 1/sqrt(N).
    # Grover's iterate uses the good/bad two-dimensional plane; rounded iterations
    # provide >=2/3 success in these examples, using O(sqrt(N)) oracle calls.
    for n in (55, 487, 1459):
        t = round(pi / (4 * asin(1 / sqrt(n))) - Fraction(1, 2))
        probability = sin((2 * t + 1) * asin(1 / sqrt(n))) ** 2
        ok &= check(f'E unique-mark search N={n}',
                    Fraction(1, n) < Fraction(1, 2)
                    and t < n and probability >= Fraction(2, 3),
                    f'mean=1/{n}, Grover queries={t}, success={probability:.6f}')

    # These are *not* computed QSVT/AE circuits: flag the scope in the output.
    print('SCOPE: QSVT, block-encoding implementation, controlled preparation,')
    print('       amplitude estimation, and gate cost are assumptions/theorems, not simulated.')
    print('ALL EXACT FINITE CHECKS PASS' if ok else 'SOME FINITE CHECKS FAILED')
    return ok


if __name__ == '__main__':
    raise SystemExit(0 if run() else 1)
