#!/usr/bin/env python3
"""Theorem 1 verification (zero-arrow / vertex-simple formulation, matching the corrected theorem).
Substrate: g=2, p=3 Mumford curve; dual graph G = bouquet of two 2-cycles at v0. V={v0,m1,m2}.
Phi_deg(d) = (+)_v S_v^{d_v}, where S_v is the vertex-simple module of the complete path algebra
A = C[Gbar]: C at v, 0 elsewhere, every arrow acts by ZERO. Each claim tested independently.

  (1) Degree recovery: dim Phi_deg(d) read from the module = d (per-vertex).
  (2) Monoidality: Phi_deg(d+e) = Phi_deg(d) (+) Phi_deg(e) as A-modules -- arrow maps are zero on
      both sides, so the vertexwise block-sum is a literal A-module isomorphism (checked as matrices).
  (3) Full path action: vertex idempotents act as vertex projectors; EVERY positive-length path acts
      by zero (checked for all arrows and all length-2 paths).
  (4) Faithfulness: distinct multidegrees -> non-isomorphic modules (distinct dimension vectors).
  (Arithmetic pairing, item 4 of the theorem) checked SEPARATELY: cycle/monodromy pairing on H_1(G)
      equals the independently computed Schottky period valuation matrix.
"""
import numpy as np
from fractions import Fraction as Fr
def check(name, ok, detail=""):
    print(f"[{'PASS' if ok else 'FAIL'}] {name}  {detail}")
    return ok
allok=True

V=['v0','m1','m2']
arcs=[('v0','m1','e1a'),('m1','v0','e1a'),('v0','m1','e1b'),('m1','v0','e1b'),
      ('v0','m2','e2a'),('m2','v0','e2a'),('v0','m2','e2b'),('m2','v0','e2b')]

def phi_deg(d):
    tags=[(v,k) for v in V for k in range(d[v])]
    ti={t:i for i,t in enumerate(tags)}; D=len(tags)
    arrow_ops={ar: np.zeros((D,D)) for ar in arcs}
    def proj(v): return np.diag([1.0 if t[0]==v else 0.0 for t in tags])
    return D,tags,ti,arrow_ops,proj

# (1) degree recovery
rng=np.random.default_rng(0); ok1=True
for _ in range(1000):
    d={v:int(rng.integers(0,6)) for v in V}
    D,tags,ti,ops,proj=phi_deg(d)
    dimvec={v:sum(1 for t in tags if t[0]==v) for v in V}
    if dimvec!=d or D!=sum(d.values()): ok1=False
allok &= check("(1) degree recovery: dim Phi_deg(d) read from module = d", ok1, "1000 classes")

# (2) monoidality as literal A-module iso (arrow maps zero on both sides => block-sum is an iso)
ok2=True
for _ in range(300):
    d={v:int(rng.integers(0,4)) for v in V}; e={v:int(rng.integers(0,4)) for v in V}
    Dd,_,_,od,_=phi_deg(d); De,_,_,oe,_=phi_deg(e)
    s={v:d[v]+e[v] for v in V}; Ds,_,_,os,_=phi_deg(s)
    for ar in arcs:
        bd=np.zeros((Dd+De,Dd+De)); bd[:Dd,:Dd]=od[ar]; bd[Dd:,Dd:]=oe[ar]
        # both are zero; the block-sum equals Phi(d+e)'s (zero) arrow op up to the trivial vertex reindex
        if not (np.allclose(bd,0) and np.allclose(os[ar],0)): ok2=False
    if (Dd+De)!=Ds: ok2=False
allok &= check("(2) monoidality: Phi(d+e)=Phi(d)(+)Phi(e), arrow maps zero both sides", ok2, "300 pairs")

# (3) full path action: vertex idempotents = projectors; every positive-length path acts by zero
d={'v0':2,'m1':2,'m2':2}; D,tags,ti,ops,proj=phi_deg(d)
# vertex projectors are idempotent, orthogonal, sum to I
Ps={v:proj(v) for v in V}
idem=all(np.allclose(Ps[v]@Ps[v],Ps[v]) for v in V)
orth=all(np.allclose(Ps[v]@Ps[w],0) for v in V for w in V if v!=w)
summ=np.allclose(sum(Ps.values()),np.eye(D))
# arrows act by zero; length-2 paths (composition of two arrows) also zero
arrows_zero=all(np.allclose(ops[ar],0) for ar in arcs)
len2_zero=True
for a1 in arcs:
    for a2 in arcs:
        if a1[1]==a2[0]:
            if not np.allclose(ops[a2]@ops[a1],0): len2_zero=False
allok &= check("(3) vertex idempotents are orthogonal projectors summing to I; positive-length paths act by 0",
               idem and orth and summ and arrows_zero and len2_zero)

# (4) faithfulness: distinct multidegrees -> distinct dimension vectors -> non-isomorphic
degs=[{'v0':a,'m1':b,'m2':c} for a in range(3) for b in range(3) for c in range(3)]
dimvecs=[tuple(sum(1 for t in phi_deg(dd)[1] if t[0]==v) for v in V) for dd in degs]
allok &= check("(4) faithful: distinct multidegrees -> distinct dimension vectors (non-isomorphic)",
               len(set(dimvecs))==len(degs))

# ---- Arithmetic pairing (item 4), SEPARATE: cycle pairing = Schottky period valuation matrix ----
p=3
def mul(A,B): return ((A[0][0]*B[0][0]+A[0][1]*B[1][0],A[0][0]*B[0][1]+A[0][1]*B[1][1]),
                      (A[1][0]*B[0][0]+A[1][1]*B[1][0],A[1][0]*B[0][1]+A[1][1]*B[1][1]))
def inv(A): return ((A[1][1],-A[0][1]),(-A[1][0],A[0][0]))
def mob(A,z): return (A[0][0]*z[0]+A[0][1]*z[1],A[1][0]*z[0]+A[1][1]*z[1])
def det2(z,w): return z[0]*w[1]-w[0]*z[1]
def cr(z1,z2,z3,z4): return (det2(z1,z3)*det2(z2,z4))/(det2(z1,z4)*det2(z2,z3))
def vp(x):
    if x==0: return 10**9
    n,dd=x.numerator,x.denominator; v=0
    while n%p==0:n//=p;v+=1
    while dd%p==0:dd//=p;v-=1
    return v
P2=Fr(9); I=((Fr(1),Fr(0)),(Fr(0),Fr(1)))
G1=((P2,Fr(0)),(Fr(0),Fr(1))); Hm=((Fr(2),Fr(1)),(Fr(1),Fr(1)))
G2=mul(mul(Hm,((P2,Fr(0)),(Fr(0),Fr(1)))),inv(Hm))
GEN={1:G1,-1:inv(G1),2:G2,-2:inv(G2)}
aa={1:(Fr(0),Fr(1)),2:(Fr(1),Fr(1))}; bb={1:(Fr(1),Fr(0)),2:(Fr(2),Fr(1))}; kap={1:P2,2:P2}
def words(ml):
    out=[()];fr=[()]
    for _ in range(ml):
        nx=[]
        for w in fr:
            for x in (1,-1,2,-2):
                if w and w[-1]==-x:continue
                nx.append(w+(x,))
        out+=nx;fr=nx
    return out
def wm(w):
    A=I
    for x in w:A=mul(A,GEN[x])
    return A
def reps_ij(i,j,ml):
    R=[]
    for w in words(ml):
        if w==():
            if i!=j:R.append(w)
            continue
        if abs(w[0])==i or abs(w[-1])==j:continue
        R.append(w)
    return R
def qval(i,j):
    q=kap[i] if i==j else Fr(1)
    for w in reps_ij(i,j,8):
        Dm=wm(w);c=mob(Dm,aa[j]);dd=mob(Dm,bb[j]);q*=cr(aa[i],bb[i],c,dd)
    return vp(q)
Vmat=np.array([[qval(i,j) for j in (1,2)] for i in (1,2)])
c1=np.array([1,1,0,0]);c2=np.array([0,0,1,1])
Gram=np.array([[c1@c1,c1@c2],[c2@c1,c2@c2]])
allok &= check("(item 4, separate) cycle pairing = Schottky period valuation matrix",
               np.array_equal(Gram,Vmat), f"Gram={Gram.tolist()} = v_p(q)={Vmat.tolist()}")

print("\nALL PASS" if allok else "\nSOME FAILED")
