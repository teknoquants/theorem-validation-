#!/usr/bin/env bash
set -u
cd "$(dirname "$0")/verify_scripts"
fail=0
for n in 1 2 3 4 5 6 7 8 9 10 11 12 13 14; do
  echo "===================== Theorem $n ====================="
  python3 "verify_thm${n}.py" || fail=1
  echo
done
[ $fail -eq 0 ] && echo "ALL SCRIPTS COMPLETED" || echo "AT LEAST ONE SCRIPT REPORTED A FAILURE"
